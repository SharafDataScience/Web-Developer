/**
 * Ele Animator — Editor JS
 *
 * Loaded only inside the Elementor admin editor panel (not the preview iframe).
 * The preview iframe already loads as-ea-frontend.js and handles live preview
 * via the elementor/frontend/init + frontend/element_ready/container hooks.
 *
 * This file is reserved for any future editor-panel enhancements
 * (e.g., custom control UI, panel notifications, etc.).
 *
 * No jQuery. Vanilla JS only.
 */
( function () {
	'use strict';

	// The editor is ready — Elementor fires this when the panel is fully loaded.
	window.addEventListener( 'elementor:init', function () {
		// Future: add editor-panel-specific behaviour here.
	} );

} )();
