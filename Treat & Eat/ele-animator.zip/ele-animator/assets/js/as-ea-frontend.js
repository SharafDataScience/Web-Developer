/**
 * Ele Animator — Frontend Animation Engine
 *
 * Three futuristic canvas animations:
 *   1. Neural Network  — nodes connected by a glowing web; mouse repels nodes.
 *   2. Particle Field  — glowing particles that drift and magnetically follow the cursor.
 *   3. Constellation   — sparse stars linked by dashed lines; cursor exerts gentle gravity.
 *
 * No jQuery. Vanilla JS only.
 * Uses Canvas 2D API + IntersectionObserver for off-screen performance pause.
 */
( function () {
	'use strict';

	/* =========================================================================
	 * Base Animation Class
	 * ====================================================================== */

	/**
	 * @class ASEAAnimation
	 * Shared canvas lifecycle, mouse tracking, resize handling.
	 */
	class ASEAAnimation {
		/**
		 * @param {HTMLElement} container - The Elementor container element.
		 * @param {Object}      settings  - Data-attribute settings object.
		 */
		constructor( container, settings ) {
			this.container    = container;
			this.settings     = settings;
			this.canvas       = null;
			this.ctx          = null;
			this.rafId        = null;
			this.isRunning    = false;
			this.nodes        = [];
			this.mouse        = { x: null, y: null };
			this._onMouseMove = this._onMouseMove.bind( this );
			this._onMouseLeave = this._onMouseLeave.bind( this );
			this._onResize    = this._onResize.bind( this );
		}

		/** Create the canvas, attach it before the first child, and start. */
		init() {
			this._createCanvas();
			this._bindMouse();
			this.populate();
			this.start();
		}

		/** Build and insert the <canvas> element. */
		_createCanvas() {
			this.canvas = document.createElement( 'canvas' );
			this.canvas.classList.add( 'as-ea-canvas' );
			// Insert as the very first child so content layers above it via z-index.
			this.container.insertBefore( this.canvas, this.container.firstChild );
			this.ctx = this.canvas.getContext( '2d' );
			this._sizeCanvas();

			// Resize when the container dimensions change (responsive).
			this._resizeObserver = new ResizeObserver( this._onResize );
			this._resizeObserver.observe( this.container );
		}

		/** Match canvas pixel dimensions to the container's layout size. */
		_sizeCanvas() {
			this.canvas.width  = this.container.offsetWidth  || 800;
			this.canvas.height = this.container.offsetHeight || 400;
		}

		_onResize() {
			this._sizeCanvas();
			// Re-populate so particles are distributed across the new area.
			this.populate();
		}

		/** Track mouse position relative to the container's top-left corner. */
		_bindMouse() {
			this.container.addEventListener( 'mousemove',  this._onMouseMove );
			this.container.addEventListener( 'mouseleave', this._onMouseLeave );
		}

		_onMouseMove( e ) {
			const rect    = this.container.getBoundingClientRect();
			this.mouse.x  = e.clientX - rect.left;
			this.mouse.y  = e.clientY - rect.top;
		}

		_onMouseLeave() {
			this.mouse.x = null;
			this.mouse.y = null;
		}

		/** Start the animation loop. */
		start() {
			if ( this.isRunning ) return;
			this.isRunning = true;
			this._loop();
		}

		/** Pause the animation loop (called by IntersectionObserver off-screen). */
		stop() {
			this.isRunning = false;
			if ( this.rafId ) {
				cancelAnimationFrame( this.rafId );
				this.rafId = null;
			}
		}

		/** Destroy canvas and listeners (called on element re-render). */
		destroy() {
			this.stop();
			if ( this._resizeObserver ) this._resizeObserver.disconnect();
			this.container.removeEventListener( 'mousemove',  this._onMouseMove );
			this.container.removeEventListener( 'mouseleave', this._onMouseLeave );
			if ( this.canvas && this.canvas.parentNode ) {
				this.canvas.parentNode.removeChild( this.canvas );
			}
		}

		_loop() {
			if ( ! this.isRunning ) return;
			this.draw();
			this.rafId = requestAnimationFrame( () => this._loop() );
		}

		/**
		 * Fill the canvas with the optional background colour.
		 * If no bg colour is set the canvas is transparent, allowing the
		 * container's own CSS background to show through beneath the dots.
		 */
		_clearFrame() {
			const w = this.canvas.width;
			const h = this.canvas.height;
			this.ctx.clearRect( 0, 0, w, h );

			const bg = this.settings.bgColor;
			if ( bg ) {
				this.ctx.fillStyle = bg;
				this.ctx.fillRect( 0, 0, w, h );
			}
		}

		/**
		 * Parse a CSS colour string (hex / rgb / rgba) into { r, g, b }.
		 *
		 * @param  {string} color
		 * @return {{ r: number, g: number, b: number }}
		 */
		_hexToRgb( color ) {
			if ( ! color ) return { r: 99, g: 179, b: 237 };

			// rgba? (...)
			const rgbaMatch = color.match( /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/ );
			if ( rgbaMatch ) {
				return {
					r: parseInt( rgbaMatch[1], 10 ),
					g: parseInt( rgbaMatch[2], 10 ),
					b: parseInt( rgbaMatch[3], 10 ),
				};
			}

			// #RRGGBB or #RGB
			const hex = color.replace( '#', '' );
			if ( hex.length === 3 ) {
				return {
					r: parseInt( hex[0] + hex[0], 16 ),
					g: parseInt( hex[1] + hex[1], 16 ),
					b: parseInt( hex[2] + hex[2], 16 ),
				};
			}
			if ( hex.length === 6 ) {
				return {
					r: parseInt( hex.slice( 0, 2 ), 16 ),
					g: parseInt( hex.slice( 2, 4 ), 16 ),
					b: parseInt( hex.slice( 4, 6 ), 16 ),
				};
			}

			return { r: 99, g: 179, b: 237 }; // fallback blue
		}

		/** Limit a value to [ -cap, cap ]. */
		_clampSpeed( val, cap ) {
			return Math.max( -cap, Math.min( cap, val ) );
		}

		// Sub-classes override these:
		populate() {}
		draw()     {}
	}

	/* =========================================================================
	 * 1. Neural Network
	 * ====================================================================== */

	/**
	 * @class NeuralNetwork
	 *
	 * Behaviour:
	 *   – Nodes drift in random directions, bouncing off walls.
	 *   – Nodes within `connectDist` px are joined by a glowing line.
	 *   – The mouse creates a repulsion field: nodes within `mouseRadius`
	 *     are pushed away and spring back after the cursor leaves.
	 */
	class NeuralNetwork extends ASEAAnimation {
		populate() {
			const w     = this.canvas.width;
			const h     = this.canvas.height;
			const count = parseInt( this.settings.dotCount, 10 ) || 60;
			const speed = parseFloat( this.settings.speed )       || 1;
			const size  = parseFloat( this.settings.dotSize )     || 3;
			const color = this._hexToRgb( this.settings.dotColor );

			this.nodes = [];
			for ( let i = 0; i < count; i++ ) {
				this.nodes.push( {
					x:    Math.random() * w,
					y:    Math.random() * h,
					vx:   ( Math.random() - 0.5 ) * speed,
					vy:   ( Math.random() - 0.5 ) * speed,
					r:    size,
					col:  color,
				} );
			}
		}

		draw() {
			const w            = this.canvas.width;
			const h            = this.canvas.height;
			const mouseRadius  = parseInt( this.settings.mouseRadius, 10 ) || 150;
			const connectDist  = 130;
			const maxSpeed     = 4;
			const lineRgb      = this._hexToRgb( this.settings.lineColor );

			this._clearFrame();

			// ── Update node physics ────────────────────────────────────────
			for ( const node of this.nodes ) {
				// Mouse repulsion.
				if ( this.mouse.x !== null ) {
					const dx   = node.x - this.mouse.x;
					const dy   = node.y - this.mouse.y;
					const dist = Math.sqrt( dx * dx + dy * dy );
					if ( dist < mouseRadius && dist > 0 ) {
						const force = ( mouseRadius - dist ) / mouseRadius;
						node.vx += ( dx / dist ) * force * 0.8;
						node.vy += ( dy / dist ) * force * 0.8;
					}
				}

				// Soft speed cap + gentle damping so nodes slow to base velocity.
				node.vx = this._clampSpeed( node.vx, maxSpeed ) * 0.99;
				node.vy = this._clampSpeed( node.vy, maxSpeed ) * 0.99;

				node.x += node.vx;
				node.y += node.vy;

				// Bounce off edges.
				if ( node.x < 0 )  { node.x  = 0;  node.vx *= -1; }
				if ( node.x > w )  { node.x  = w;  node.vx *= -1; }
				if ( node.y < 0 )  { node.y  = 0;  node.vy *= -1; }
				if ( node.y > h )  { node.y  = h;  node.vy *= -1; }
			}

			// ── Draw connection lines ──────────────────────────────────────
			this.ctx.lineWidth = 0.8;
			for ( let i = 0; i < this.nodes.length; i++ ) {
				for ( let j = i + 1; j < this.nodes.length; j++ ) {
					const dx   = this.nodes[i].x - this.nodes[j].x;
					const dy   = this.nodes[i].y - this.nodes[j].y;
					const dist = Math.sqrt( dx * dx + dy * dy );
					if ( dist < connectDist ) {
						const alpha = ( 1 - dist / connectDist ) * 0.55;
						this.ctx.beginPath();
						this.ctx.moveTo( this.nodes[i].x, this.nodes[i].y );
						this.ctx.lineTo( this.nodes[j].x, this.nodes[j].y );
						this.ctx.strokeStyle = `rgba(${ lineRgb.r },${ lineRgb.g },${ lineRgb.b },${ alpha })`;
						this.ctx.stroke();
					}
				}
			}

			// ── Draw nodes ─────────────────────────────────────────────────
			for ( const node of this.nodes ) {
				const { r, g, b } = node.col;

				// Outer glow.
				const glow = this.ctx.createRadialGradient(
					node.x, node.y, 0,
					node.x, node.y, node.r * 4
				);
				glow.addColorStop( 0,   `rgba(${ r },${ g },${ b },0.35)` );
				glow.addColorStop( 1,   `rgba(${ r },${ g },${ b },0)` );
				this.ctx.beginPath();
				this.ctx.arc( node.x, node.y, node.r * 4, 0, Math.PI * 2 );
				this.ctx.fillStyle = glow;
				this.ctx.fill();

				// Core dot.
				this.ctx.beginPath();
				this.ctx.arc( node.x, node.y, node.r, 0, Math.PI * 2 );
				this.ctx.fillStyle = `rgba(${ r },${ g },${ b },1)`;
				this.ctx.fill();
			}
		}
	}

	/* =========================================================================
	 * 2. Particle Field
	 * ====================================================================== */

	/**
	 * @class ParticleField
	 *
	 * Behaviour:
	 *   – Many small glowing particles drift gently.
	 *   – Each particle pulses in brightness on its own sine cycle.
	 *   – The mouse exerts a magnetic attraction: nearby particles are pulled
	 *     toward the cursor smoothly and drift back when it leaves.
	 *   – Particles wrap around container edges (no bounce).
	 */
	class ParticleField extends ASEAAnimation {
		populate() {
			const w     = this.canvas.width;
			const h     = this.canvas.height;
			const count = parseInt( this.settings.dotCount, 10 ) || 80;
			const speed = parseFloat( this.settings.speed )       || 0.5;
			const size  = parseFloat( this.settings.dotSize )     || 2;
			const color = this._hexToRgb( this.settings.dotColor );

			this.nodes = [];
			for ( let i = 0; i < count; i++ ) {
				this.nodes.push( {
					x:           Math.random() * w,
					y:           Math.random() * h,
					vx:          ( Math.random() - 0.5 ) * speed,
					vy:          ( Math.random() - 0.5 ) * speed,
					r:           size * ( 0.5 + Math.random() ),
					col:         color,
					phase:       Math.random() * Math.PI * 2,
					phaseSpeed:  0.015 + Math.random() * 0.025,
				} );
			}
		}

		draw() {
			const w           = this.canvas.width;
			const h           = this.canvas.height;
			const mouseRadius = parseInt( this.settings.mouseRadius, 10 ) || 120;
			const maxSpeed    = 3;

			this._clearFrame();

			for ( const p of this.nodes ) {
				// Mouse magnetic attraction.
				if ( this.mouse.x !== null ) {
					const dx   = this.mouse.x - p.x;
					const dy   = this.mouse.y - p.y;
					const dist = Math.sqrt( dx * dx + dy * dy );
					if ( dist < mouseRadius && dist > 0 ) {
						const force = ( mouseRadius - dist ) / mouseRadius * 0.04;
						p.vx += dx * force;
						p.vy += dy * force;
					}
				}

				p.vx = this._clampSpeed( p.vx, maxSpeed ) * 0.97;
				p.vy = this._clampSpeed( p.vy, maxSpeed ) * 0.97;

				p.x += p.vx;
				p.y += p.vy;

				// Wrap around edges instead of bouncing — feels more organic.
				if ( p.x < -p.r )      p.x = w + p.r;
				if ( p.x > w + p.r )   p.x = -p.r;
				if ( p.y < -p.r )      p.y = h + p.r;
				if ( p.y > h + p.r )   p.y = -p.r;

				// Pulsing brightness.
				p.phase += p.phaseSpeed;
				const alpha = 0.55 + 0.45 * Math.sin( p.phase ); // 0.1 → 1.0

				const { r, g, b } = p.col;
				const glowR = p.r * 5;

				// Radial glow halo.
				const glow = this.ctx.createRadialGradient(
					p.x, p.y, 0,
					p.x, p.y, glowR
				);
				glow.addColorStop( 0,   `rgba(${ r },${ g },${ b },${ alpha * 0.5 })` );
				glow.addColorStop( 0.4, `rgba(${ r },${ g },${ b },${ alpha * 0.15 })` );
				glow.addColorStop( 1,   `rgba(${ r },${ g },${ b },0)` );
				this.ctx.beginPath();
				this.ctx.arc( p.x, p.y, glowR, 0, Math.PI * 2 );
				this.ctx.fillStyle = glow;
				this.ctx.fill();

				// Core bright dot.
				this.ctx.beginPath();
				this.ctx.arc( p.x, p.y, p.r, 0, Math.PI * 2 );
				this.ctx.fillStyle = `rgba(${ r },${ g },${ b },${ alpha })`;
				this.ctx.fill();
			}
		}
	}

	/* =========================================================================
	 * 3. Constellation
	 * ====================================================================== */

	/**
	 * @class Constellation
	 *
	 * Behaviour:
	 *   – Sparse star-like nodes that twinkle (sine-based alpha).
	 *   – Close neighbours are joined by dashed lines (like star maps).
	 *   – The mouse exerts a slow gravitational pull on nearby stars.
	 *   – Stars bounce off walls gently.
	 */
	class Constellation extends ASEAAnimation {
		populate() {
			const w     = this.canvas.width;
			const h     = this.canvas.height;
			const count = parseInt( this.settings.dotCount, 10 ) || 40;
			const speed = parseFloat( this.settings.speed )       || 0.3;
			const size  = parseFloat( this.settings.dotSize )     || 2;
			const color = this._hexToRgb( this.settings.dotColor );

			this.nodes = [];
			for ( let i = 0; i < count; i++ ) {
				this.nodes.push( {
					x:          Math.random() * w,
					y:          Math.random() * h,
					vx:         ( Math.random() - 0.5 ) * speed,
					vy:         ( Math.random() - 0.5 ) * speed,
					r:          size * ( 0.6 + Math.random() * 0.8 ),
					col:        color,
					phase:      Math.random() * Math.PI * 2,
					phaseSpeed: 0.008 + Math.random() * 0.012,
				} );
			}
		}

		draw() {
			const w           = this.canvas.width;
			const h           = this.canvas.height;
			const mouseRadius = parseInt( this.settings.mouseRadius, 10 ) || 130;
			const connectDist = 180;
			const maxSpeed    = 1.5;
			const lineRgb     = this._hexToRgb( this.settings.lineColor );

			this._clearFrame();

			// ── Update star physics ────────────────────────────────────────
			for ( const star of this.nodes ) {
				// Gentle gravitational pull toward mouse.
				if ( this.mouse.x !== null ) {
					const dx   = this.mouse.x - star.x;
					const dy   = this.mouse.y - star.y;
					const dist = Math.sqrt( dx * dx + dy * dy );
					if ( dist < mouseRadius && dist > 0 ) {
						const force = ( mouseRadius - dist ) / mouseRadius * 0.012;
						star.vx += dx * force;
						star.vy += dy * force;
					}
				}

				star.vx = this._clampSpeed( star.vx, maxSpeed ) * 0.995;
				star.vy = this._clampSpeed( star.vy, maxSpeed ) * 0.995;

				star.x += star.vx;
				star.y += star.vy;

				if ( star.x < 0 )  { star.x  = 0;  star.vx *= -1; }
				if ( star.x > w )  { star.x  = w;  star.vx *= -1; }
				if ( star.y < 0 )  { star.y  = 0;  star.vy *= -1; }
				if ( star.y > h )  { star.y  = h;  star.vy *= -1; }
			}

			// ── Draw dashed constellation lines ────────────────────────────
			this.ctx.setLineDash( [ 4, 6 ] );
			this.ctx.lineWidth = 0.7;
			for ( let i = 0; i < this.nodes.length; i++ ) {
				for ( let j = i + 1; j < this.nodes.length; j++ ) {
					const dx   = this.nodes[i].x - this.nodes[j].x;
					const dy   = this.nodes[i].y - this.nodes[j].y;
					const dist = Math.sqrt( dx * dx + dy * dy );
					if ( dist < connectDist ) {
						const alpha = ( 1 - dist / connectDist ) * 0.35;
						this.ctx.beginPath();
						this.ctx.moveTo( this.nodes[i].x, this.nodes[i].y );
						this.ctx.lineTo( this.nodes[j].x, this.nodes[j].y );
						this.ctx.strokeStyle = `rgba(${ lineRgb.r },${ lineRgb.g },${ lineRgb.b },${ alpha })`;
						this.ctx.stroke();
					}
				}
			}
			this.ctx.setLineDash( [] );

			// ── Draw stars ─────────────────────────────────────────────────
			for ( const star of this.nodes ) {
				star.phase += star.phaseSpeed;
				const alpha = 0.4 + 0.6 * ( ( 1 + Math.sin( star.phase ) ) / 2 );

				const { r, g, b } = star.col;

				// Subtle glow corona.
				const glow = this.ctx.createRadialGradient(
					star.x, star.y, 0,
					star.x, star.y, star.r * 3.5
				);
				glow.addColorStop( 0,   `rgba(${ r },${ g },${ b },${ alpha * 0.5 })` );
				glow.addColorStop( 1,   `rgba(${ r },${ g },${ b },0)` );
				this.ctx.beginPath();
				this.ctx.arc( star.x, star.y, star.r * 3.5, 0, Math.PI * 2 );
				this.ctx.fillStyle = glow;
				this.ctx.fill();

				// Star core — cross / diamond shape for extra sci-fi feel.
				this.ctx.beginPath();
				this.ctx.arc( star.x, star.y, star.r, 0, Math.PI * 2 );
				this.ctx.fillStyle = `rgba(${ r },${ g },${ b },${ alpha })`;
				this.ctx.fill();

				// Tiny cross spike.
				const spike = star.r * 2.5 * alpha;
				this.ctx.strokeStyle = `rgba(${ r },${ g },${ b },${ alpha * 0.6 })`;
				this.ctx.lineWidth   = 0.8;
				this.ctx.beginPath();
				this.ctx.moveTo( star.x - spike, star.y );
				this.ctx.lineTo( star.x + spike, star.y );
				this.ctx.moveTo( star.x, star.y - spike );
				this.ctx.lineTo( star.x, star.y + spike );
				this.ctx.stroke();
			}
		}
	}

	/* =========================================================================
	 * Controller — finds containers, creates animation instances
	 * ====================================================================== */

	const AS_EA = {
		/** Map<HTMLElement, ASEAAnimation> */
		instances: new Map(),

		/**
		 * Scan a root element for animated containers and initialise them.
		 *
		 * @param {HTMLElement} root
		 */
		initContainers( root ) {
			const els = root.querySelectorAll
				? root.querySelectorAll( '[data-as-ea-type]' )
				: [];

			els.forEach( el => this.initContainer( el ) );

			// If root itself is an animated container (e.g. Elementor element_ready).
			if ( root.dataset && root.dataset.asEaType ) {
				this.initContainer( root );
			}
		},

		/**
		 * Initialise one container element.
		 *
		 * @param {HTMLElement} container
		 */
		initContainer( container ) {
			// Destroy previous instance if the element was re-rendered.
			if ( this.instances.has( container ) ) {
				this.instances.get( container ).destroy();
				this.instances.delete( container );
			}

			// Read settings from data-* attributes stamped by PHP.
			const settings = {
				dotColor:    container.dataset.asEaDotColor    || '#63B3ED',
				lineColor:   container.dataset.asEaLineColor   || '#63B3ED',
				bgColor:     container.dataset.asEaBgColor     || '',
				dotCount:    container.dataset.asEaDotCount    || '60',
				dotSize:     container.dataset.asEaDotSize     || '3',
				speed:       container.dataset.asEaSpeed       || '1',
				mouseRadius: container.dataset.asEaMouseRadius || '150',
			};

			let animation;
			switch ( container.dataset.asEaType ) {
				case 'neural_network':
					animation = new NeuralNetwork( container, settings );
					break;
				case 'particle_field':
					animation = new ParticleField( container, settings );
					break;
				case 'constellation':
					animation = new Constellation( container, settings );
					break;
				default:
					return; // Unknown type — bail.
			}

			animation.init();
			this.instances.set( container, animation );

			// Pause the animation loop when the container scrolls out of view.
			// This significantly reduces CPU/GPU usage on long pages.
			const observer = new IntersectionObserver(
				( entries ) => {
					entries.forEach( entry => {
						if ( entry.isIntersecting ) {
							animation.start();
						} else {
							animation.stop();
						}
					} );
				},
				{ threshold: 0.05 }
			);
			observer.observe( container );
		},

		/** Full-page init (called on DOMContentLoaded / wp_enqueue). */
		init() {
			this.initContainers( document );
		},
	};

	/* =========================================================================
	 * Bootstrap
	 * ====================================================================== */

	// Public-facing pages.
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', () => AS_EA.init() );
	} else {
		AS_EA.init();
	}

	// Elementor editor preview iframe — re-init when a container is rendered/updated.
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( typeof elementorFrontend === 'undefined' ) return;

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/container',
			function ( $scope ) {
				// $scope is a jQuery object; get the raw DOM element.
				const el = $scope && $scope[0] ? $scope[0] : null;
				if ( el ) AS_EA.initContainers( el );
			}
		);

		// Legacy sections support.
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/section',
			function ( $scope ) {
				const el = $scope && $scope[0] ? $scope[0] : null;
				if ( el ) AS_EA.initContainers( el );
			}
		);
	} );

	// Expose for debugging and potential external use.
	window.ASEA = AS_EA;

} )();
