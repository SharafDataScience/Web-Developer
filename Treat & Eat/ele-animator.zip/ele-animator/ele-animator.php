<?php
/**
 * Plugin Name:       Ele Animator
 * Plugin URI:        https://github.com/
 * Description:       Adds futuristic animated canvas backgrounds (Neural Network, Particle Field, Constellation) to Elementor containers with interactive mouse tracking.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ele-animator
 * Domain Path:       /languages
 * Requires Plugins:  elementor
 * Elementor tested up to: 3.22.0
 * Elementor Pro tested up to: 3.22.0
 */

// Guard: prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'AS_EA_VERSION', '1.0.0' );
define( 'AS_EA_FILE',    __FILE__ );
define( 'AS_EA_PATH',    plugin_dir_path( __FILE__ ) );
define( 'AS_EA_URL',     plugin_dir_url( __FILE__ ) );
define( 'AS_EA_SLUG',    'ele-animator' );

// Bootstrap the plugin after all plugins are loaded.
require_once AS_EA_PATH . 'includes/class-as-ea-plugin.php';

add_action( 'plugins_loaded', array( 'AS_EA_Plugin', 'instance' ) );
