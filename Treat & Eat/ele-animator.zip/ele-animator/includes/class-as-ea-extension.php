<?php
/**
 * Elementor Extension — injects "Animated Background" controls into
 * the Container (and legacy Section) Style tab, then stamps the chosen
 * settings onto the rendered HTML as data-* attributes so the frontend
 * JS animation engine can read them.
 *
 * Hooks used
 * ──────────
 * elementor/element/container/section_background/after_section_end
 *   → adds our new controls section right after Elementor's Background section.
 *
 * elementor/element/section/section_background/after_section_end
 *   → same for legacy Section elements (backwards-compat).
 *
 * elementor/frontend/container/before_render
 * elementor/frontend/section/before_render
 *   → adds data-as-ea-* attributes to the wrapper element so the JS
 *     engine can pick up settings without extra AJAX calls.
 *
 * @package Ele_Animator
 */

// Guard: prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AS_EA_Extension
 */
class AS_EA_Extension {

	/**
	 * Constructor — wire up all hooks.
	 */
	public function __construct() {
		// ── Control registration ──────────────────────────────────────────
		// Modern Elementor Containers.
		add_action(
			'elementor/element/container/section_background/after_section_end',
			array( $this, 'as_ea_register_animation_section' ),
			10,
			2
		);

		// Legacy Sections (Elementor < 3.16 flexbox-off sites).
		add_action(
			'elementor/element/section/section_background/after_section_end',
			array( $this, 'as_ea_register_animation_section' ),
			10,
			2
		);

		// ── Frontend render attributes ────────────────────────────────────
		add_action(
			'elementor/frontend/container/before_render',
			array( $this, 'as_ea_before_render' )
		);

		add_action(
			'elementor/frontend/section/before_render',
			array( $this, 'as_ea_before_render' )
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Control registration
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Register the "Animated Background" controls section on the given element.
	 *
	 * Called via elementor/element/{type}/section_background/after_section_end.
	 *
	 * @param \Elementor\Element_Base $element  The element being edited.
	 * @param array                   $args     Hook arguments (unused).
	 * @return void
	 */
	public function as_ea_register_animation_section( $element, $args ) {

		$element->start_controls_section(
			'as_ea_section_animated_bg',
			array(
				'label' => esc_html__( 'Animated Background', 'ele-animator' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// ── Master toggle ─────────────────────────────────────────────────
		$element->add_control(
			'as_ea_enable',
			array(
				'label'        => esc_html__( 'Enable Animated Background', 'ele-animator' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'ele-animator' ),
				'label_off'    => esc_html__( 'No', 'ele-animator' ),
				'return_value' => 'yes',
				'default'      => '',
				// Security note: no user-capability gate needed here because
				// Elementor already restricts the editor to users who can edit posts.
			)
		);

		// ── Animation type ────────────────────────────────────────────────
		$element->add_control(
			'as_ea_animation_type',
			array(
				'label'     => esc_html__( 'Animation Type', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'neural_network',
				'options'   => array(
					'neural_network' => esc_html__( 'Neural Network — nodes connected by a shifting web', 'ele-animator' ),
					'particle_field' => esc_html__( 'Particle Field — glowing particles with magnetic pull', 'ele-animator' ),
					'constellation'  => esc_html__( 'Constellation — sparse stars linked by dashed lines', 'ele-animator' ),
				),
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// ── Colors heading ────────────────────────────────────────────────
		$element->add_control(
			'as_ea_colors_heading',
			array(
				'label'     => esc_html__( 'Colors', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Dot / particle colour.
		$element->add_control(
			'as_ea_dot_color',
			array(
				'label'     => esc_html__( 'Dot Color', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#63B3ED',
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Connector line colour — only relevant for neural_network & constellation.
		$element->add_control(
			'as_ea_line_color',
			array(
				'label'     => esc_html__( 'Line Color', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#63B3ED',
				'condition' => array(
					'as_ea_enable'          => 'yes',
					// Hide for Particle Field (no lines drawn).
					'as_ea_animation_type!' => 'particle_field',
				),
			)
		);

		// Optional solid canvas background colour.
		$element->add_control(
			'as_ea_bg_color',
			array(
				'label'       => esc_html__( 'Canvas Background Color', 'ele-animator' ),
				'description' => esc_html__( 'Leave empty to overlay animation on your existing background.', 'ele-animator' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'default'     => '',
				'condition'   => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// ── Particle settings heading ─────────────────────────────────────
		$element->add_control(
			'as_ea_particles_heading',
			array(
				'label'     => esc_html__( 'Particle Settings', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Number of dots / particles.
		$element->add_control(
			'as_ea_dot_count',
			array(
				'label'     => esc_html__( 'Dot Count', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 10,
						'max'  => 200,
						'step' => 5,
					),
				),
				'default'   => array( 'size' => 60 ),
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Dot radius.
		$element->add_control(
			'as_ea_dot_size',
			array(
				'label'     => esc_html__( 'Dot Size', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 1,
						'max'  => 10,
						'step' => 0.5,
					),
				),
				'default'   => array( 'size' => 3 ),
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Animation speed multiplier.
		$element->add_control(
			'as_ea_speed',
			array(
				'label'     => esc_html__( 'Animation Speed', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 0.1,
						'max'  => 5,
						'step' => 0.1,
					),
				),
				'default'   => array( 'size' => 1 ),
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// ── Mouse interaction heading ─────────────────────────────────────
		$element->add_control(
			'as_ea_mouse_heading',
			array(
				'label'     => esc_html__( 'Mouse Interaction', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		// Radius within which particles react to the cursor.
		$element->add_control(
			'as_ea_mouse_radius',
			array(
				'label'     => esc_html__( 'Mouse Influence Radius (px)', 'ele-animator' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 50,
						'max'  => 400,
						'step' => 10,
					),
				),
				'default'   => array( 'size' => 150 ),
				'condition' => array( 'as_ea_enable' => 'yes' ),
			)
		);

		$element->end_controls_section();
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Frontend render attributes
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Stamp data-as-ea-* attributes onto the container/section wrapper element
	 * so the frontend JS can read settings without a separate AJAX call.
	 *
	 * Called via elementor/frontend/{type}/before_render.
	 *
	 * @param \Elementor\Element_Base $element  The element being rendered.
	 * @return void
	 */
	public function as_ea_before_render( $element ) {
		$settings = $element->get_settings_for_display();

		// Bail early if the animated background is not enabled on this element.
		if ( 'yes' !== ( $settings['as_ea_enable'] ?? '' ) ) {
			return;
		}

		/*
		 * Security: all values are sanitized before output.
		 * Elementor's add_render_attribute() additionally escapes the value
		 * with esc_attr() when it writes the HTML attribute, giving us a
		 * second layer of XSS protection.
		 */

		// Animation type — restrict to our known keys via sanitize_key().
		$allowed_types = array( 'neural_network', 'particle_field', 'constellation' );
		$animation_type = sanitize_key( $settings['as_ea_animation_type'] ?? 'neural_network' );
		if ( ! in_array( $animation_type, $allowed_types, true ) ) {
			$animation_type = 'neural_network';
		}
		$element->add_render_attribute( '_wrapper', 'data-as-ea-type', $animation_type );

		// Colours — validate as hex or rgba strings.
		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-dot-color',
			$this->as_ea_sanitize_color( $settings['as_ea_dot_color'] ?? '#63B3ED' )
		);

		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-line-color',
			$this->as_ea_sanitize_color( $settings['as_ea_line_color'] ?? '#63B3ED' )
		);

		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-bg-color',
			$this->as_ea_sanitize_color( $settings['as_ea_bg_color'] ?? '' )
		);

		// Numeric settings — cast to safe types.
		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-dot-count',
			absint( $settings['as_ea_dot_count']['size'] ?? 60 )
		);

		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-dot-size',
			(float) ( $settings['as_ea_dot_size']['size'] ?? 3 )
		);

		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-speed',
			(float) ( $settings['as_ea_speed']['size'] ?? 1 )
		);

		$element->add_render_attribute(
			'_wrapper',
			'data-as-ea-mouse-radius',
			absint( $settings['as_ea_mouse_radius']['size'] ?? 150 )
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Helpers
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Sanitize a CSS color string — accepts hex (#RGB / #RRGGBB) or
	 * rgb() / rgba() formats returned by Elementor's COLOR control.
	 *
	 * Returns an empty string for invalid / empty values so the JS
	 * animation engine can fall back to its own default.
	 *
	 * @param string $color  Raw color value from the control.
	 * @return string        Safe color string or empty string.
	 */
	private function as_ea_sanitize_color( $color ) {
		$color = trim( (string) $color );

		if ( '' === $color ) {
			return '';
		}

		// Hex shorthand #RGB or full #RRGGBB.
		if ( preg_match( '/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/', $color ) ) {
			return $color;
		}

		// rgb() / rgba() — digits, spaces, commas, and a decimal for alpha only.
		if ( preg_match( '/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*(0|1|0?\.\d+))?\s*\)$/', $color ) ) {
			return $color;
		}

		// Anything else is rejected.
		return '';
	}
}
