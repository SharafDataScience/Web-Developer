<?php
/**
 * Main plugin class — singleton bootstrap.
 *
 * Responsibilities:
 *   - Verify Elementor is active before doing anything.
 *   - Register frontend / editor / preview assets.
 *   - Load the Elementor extension after Elementor is ready.
 *
 * @package Ele_Animator
 */

// Guard: prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AS_EA_Plugin
 */
final class AS_EA_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var AS_EA_Plugin|null
	 */
	private static $_instance = null;

	/**
	 * Return (or create) the singleton instance.
	 *
	 * @return AS_EA_Plugin
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor — private to enforce singleton.
	 */
	private function __construct() {
		// Elementor must be active; abort with an admin notice otherwise.
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'as_ea_admin_notice_missing_elementor' ) );
			return;
		}

		$this->as_ea_init_hooks();
	}

	/**
	 * Register all WordPress / Elementor hooks.
	 *
	 * @return void
	 */
	private function as_ea_init_hooks() {
		// Frontend public pages.
		add_action( 'wp_enqueue_scripts', array( $this, 'as_ea_enqueue_frontend_assets' ) );

		// Elementor live-preview iframe (editor sidebar).
		add_action( 'elementor/preview/enqueue_scripts', array( $this, 'as_ea_enqueue_frontend_assets' ) );

		// Elementor editor panel (admin side, not the iframe).
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'as_ea_enqueue_editor_assets' ) );

		// Load our Elementor extension (controls + render attributes) after Elementor is initialised.
		add_action( 'elementor/init', array( $this, 'as_ea_load_extension' ) );
	}

	/**
	 * Load the Elementor extension class and instantiate it.
	 *
	 * @return void
	 */
	public function as_ea_load_extension() {
		require_once AS_EA_PATH . 'includes/class-as-ea-extension.php';
		new AS_EA_Extension();
	}

	/**
	 * Enqueue frontend CSS + JS (public pages and editor preview iframe).
	 *
	 * Assets are registered so Elementor can decide when to load them;
	 * we then enqueue them for any page that may contain animated containers.
	 *
	 * @return void
	 */
	public function as_ea_enqueue_frontend_assets() {
		wp_enqueue_style(
			'as-ea-frontend',
			AS_EA_URL . 'assets/css/as-ea-frontend.css',
			array(),
			AS_EA_VERSION
		);

		// Load in footer (true) — canvas JS does not block rendering.
		wp_enqueue_script(
			'as-ea-frontend',
			AS_EA_URL . 'assets/js/as-ea-frontend.js',
			array(),
			AS_EA_VERSION,
			true
		);
	}

	/**
	 * Enqueue editor-only CSS + JS (admin editor panel, not the preview iframe).
	 *
	 * @return void
	 */
	public function as_ea_enqueue_editor_assets() {
		wp_enqueue_style(
			'as-ea-editor',
			AS_EA_URL . 'assets/css/as-ea-editor.css',
			array(),
			AS_EA_VERSION
		);

		wp_enqueue_script(
			'as-ea-editor',
			AS_EA_URL . 'assets/js/as-ea-editor.js',
			array( 'elementor-editor' ),
			AS_EA_VERSION,
			true
		);
	}

	/**
	 * Show an admin notice when Elementor is not active.
	 *
	 * @return void
	 */
	public function as_ea_admin_notice_missing_elementor() {
		/* translators: 1: Plugin name  2: Elementor */
		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'ele-animator' ),
			'<strong>' . esc_html__( 'Ele Animator', 'ele-animator' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'ele-animator' ) . '</strong>'
		);

		printf(
			'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
			wp_kses_post( $message )
		);
	}

	// Prevent cloning and unserializing of the singleton.
	private function __clone() {}

	/**
	 * @throws \Exception
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize the AS_EA_Plugin singleton.' );
	}
}
